import cocotb
from cocotb.triggers import RisingEdge
from cocotb.clock import Clock
from helpers import send_header, wait_for_new_msg, check_header
import random

@cocotb.test()
async def test_basic_header(dut):
    """Test a single valid header sequence."""
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    dut.rst.value = 1
    dut.rx_valid.value = 0
    dut.rx_data.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    await send_header(dut, 0x41, 0x0011)
    await wait_for_new_msg(dut)
    check_header(dut, 0x41, 0x0011)

@cocotb.test()
async def test_multiple_headers(dut):
    """Send two valid headers in succession."""
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    dut.rst.value = 1
    dut.rx_valid.value = 0
    dut.rx_data.value = 0
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    headers = [(0x10, 0x0003), (0x99, 0xABCD)]
    for msg_type, msg_len in headers:
        await send_header(dut, msg_type, msg_len)
        await wait_for_new_msg(dut)
        check_header(dut, msg_type, msg_len)

@cocotb.test()
async def test_random_headers(dut):
    """Test several randomized headers."""
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    dut.rst.value = 1
    dut.rx_valid.value = 0
    dut.rx_data.value = 0
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    for _ in range(5):
        msg_type = random.randint(0, 255)
        msg_len = random.randint(0, 0xFFFF)
        await send_header(dut, msg_type, msg_len)
        await wait_for_new_msg(dut)
        check_header(dut, msg_type, msg_len)

@cocotb.test()
async def test_reset_midstream(dut):
    """Reset in the middle of a message to see if parser recovers."""
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    dut.rst.value = 0
    dut.rx_valid.value = 1
    dut.rx_data.value = 0x55
    await RisingEdge(dut.clk)

    dut.rx_data.value = 0xAA
    await RisingEdge(dut.clk)

    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    await send_header(dut, 0x42, 0x0021)
    await wait_for_new_msg(dut)
    check_header(dut, 0x42, 0x0021)
