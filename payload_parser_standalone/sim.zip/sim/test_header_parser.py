# =============================================
# test_header_parser.py
# =============================================

# Description: Cocotb testbench for validating the Header Parser module.
# Author: RZ
# Start Date: 04292025
# Version: 0.1

# Changelog
# =============================================
# [20250429-1] RZ: Initial version created for header_parser standalone validation.
#                  Implemented basic start_flag and payload forwarding tests.
#                  Verified payload_valid_out behavior across multiple payload bytes.
# =============================================


import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.result import TestFailure

@cocotb.test()
async def header_parser_basic_test(dut):
    """Basic functionality test for header_parser"""

    # Reset
    dut.rst_n.value = 0
    dut.tcp_payload_in.value = 0
    dut.tcp_byte_valid_in.value = 0

    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst_n <= 1
    await RisingEdge(dut.clk)

    # Define a fake TCP payload stream (e.g., a message of 3 bytes)
    payload_stream = [0x2A, 0x3B, 0x4C]  # Random bytes
    expected_start_flag_cycle = 1  # We expect start_flag during first byte

    # Inject the payload into the DUT
    for idx, byte in enumerate(payload_stream):
        dut.tcp_payload_in <= byte
        dut.tcp_byte_valid_in <= 1
        await RisingEdge(dut.clk)

        # Check payload output and valid signal
        if dut.payload_out.value.integer != byte:
            raise TestFailure(f"Payload mismatch at byte {idx}: expected {hex(byte)}, got {hex(dut.payload_out.value.integer)}")

        if dut.payload_valid_out.value != 1:
            raise TestFailure(f"Payload valid not asserted at byte {idx}")

        # Check start_flag only on the first byte
        if idx == 0:
            if dut.start_flag.value != 1:
                raise TestFailure("Start flag not asserted on first byte")
        else:
            if dut.start_flag.value != 0:
                raise TestFailure("Start flag wrongly asserted after first byte")

    # After sending all bytes, drop valid
    dut.tcp_byte_valid_in <= 0
    await RisingEdge(dut.clk)

    # Confirm outputs idle
    if dut.payload_valid_out.value != 0:
        raise TestFailure("Payload valid should be deasserted after end of stream")

    cocotb.log.info("Header parser basic test PASSED")
